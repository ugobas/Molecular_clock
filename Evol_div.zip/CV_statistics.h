void CV_statistics(char *name_in, char *head, char *OUTG, char *ALI,
		   char *name_div, float **div, float **CV, float **t,
		   int **nout, int **nsign, int **nTIV,
		   float **Seq_Id, float SI_thr,
		   float **fun_sim_Seq, float fun_low, float fun_high,
		   int N, int dist, char *funtype);
