int Compute_contact_list(struct protein *prot, char cont_type, float cont_thr,
			 int IJ_MIN);
