float Compute_Dcont(float q, int L1, int L2, int *related);
