char Get_compression(char *pdb_name);
int Num_lines(char *file_name);
int Find_name(char *name2, char **name, int N, int Np);
int Change_ext(char *name_out, char *name_in, char *ext);
