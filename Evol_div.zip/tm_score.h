float TM_score(float **xca1_store, int *ali1, int nres_1,
	       float **xca2_store, int *ali2, int nres_2,
	       int nali);
