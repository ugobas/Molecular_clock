double rmsd_mclachlan(double *x1, double *x2, double *wt1, int n);
double rmsd_mclachlan_f(float *x1, float *x2, float *wt1, int n);
