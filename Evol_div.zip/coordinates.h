void Shift_coord(float **x, float *x_ave, int N);
void Rotate_coord(float **x, int N, float *r);
void Average_coord(float *x_ave, float **x, int N);
void Copy_coordinates(float **xca, float **xca_store, int nres);
float dist2(float *x1, float *x2);
